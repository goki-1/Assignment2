#ifndef _DRAW_STUFF_H_
#define _DRAW_STUFF_H_

void DrawStuff_init();
void DrawStuff_cleanup();

void DrawStuff_updateScreen(char* message);

#endif